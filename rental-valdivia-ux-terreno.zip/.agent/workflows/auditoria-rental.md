---
description: Auditoría integral de Rental Valdivia (arquitectura modular, seguridad HMAC, SQLite WAL, lógica operativa de arriendo/taller y cola offline PWA) sin modificar código.
---

Actúa como **Arquitecto Senior de Software, Especialista en Seguridad Full-Stack y Consultor de Operaciones para Arriendo de Maquinaria (Rental)**.

Tu misión es realizar una **auditoría exhaustiva del repositorio actual de Rental Valdivia** para verificar la solidez de la arquitectura actual, detectar vulnerabilidades o casos borde que se estén pasando por alto en producción y proponer optimizaciones concretas antes de escalar flota y uso en faena.

**REGLA ESTRICTA:** NO modifiques ningún archivo ni ejecutes comandos destructivos. Solo lee, analiza y entrega un informe estructurado con evidencia exacta (archivo y líneas).

## 1. Alcance de Lectura Obligatoria
Revisa el proyecto completo antes de emitir conclusiones:
- **Configuración y Entrada**: `package.json`, `tsconfig.json`, `vite.config.ts`, `.env.example`, `index.html`, `metadata.json`, `public/manifest.webmanifest`, `server.ts`
- **Backend Modular (`/server`)**:
  - `server/security.ts` (sesión HMAC-SHA256 `HttpOnly`, middleware `createRequireJefe`, validación de imágenes Base64 por magic bytes)
  - `server/db.ts` (SQLite WAL incremental, tablas relacionales incluyendo `ot_repuestos` e `idempotency_keys`, respaldo JSON diferido)
  - `server/routes/fleet.ts`, `server/routes/emergencies.ts`, `server/routes/workshop.ts`, `server/routes/management.ts`
- **Frontend Núcleo y Offline (`/src`)**:
  - `src/main.tsx`, `src/App.tsx`, `src/index.css`, `src/data/catalogs.ts`
  - `src/lib/apiClient.ts`, `src/lib/offlineStore.ts`
  - `src/hooks/useOnlineStatus.ts`, `src/hooks/usePWAInstall.ts`
- **Módulos de Interfaz (`/src/components`)**:
  - `EstacionTrabajo.tsx` + `estacion/RecepcionDespachoTab.tsx`, `estacion/TallerMecTab.tsx`, `estacion/PresupuestoAjusteTabs.tsx`
  - `PanelJefatura.tsx` + `jefatura/JefaturaEmergenciasTab.tsx`, `jefatura/JefaturaPresupuestosTab.tsx`, `jefatura/JefaturaOtsBodegaTabs.tsx`, `jefatura/JefaturaAnaliticaArriendosTab.tsx`
  - `SemaforoPatio.tsx`, `ModuloEmergencia.tsx`, `EnrolarMaquina.tsx`, `InformePdfModal.tsx`

## 2. Ejes de Auditoría (Qué debes verificar específicamente)

1. **Seguridad y Control de Acceso Real (Frontend vs Backend)**
   - Verifica que todas las rutas ejecutivas, de bodega, administración y respaldo exijan `requireJefe` basado en cookie HMAC-SHA256 (`rv_jefe_session`) o verificación server-side antes de leer/mutar entidades, sin confiar en flags del cliente ni exponer secretos en `/api/state`.
   - Audita gestión de `SESSION_SECRET`, `PASSWORD_JEFE`, subida de evidencias (`/evidencias`), límites de payload, cabeceras de seguridad (CSP/CORS/rate-limiting), y posible fuga de datos sensibles en modo offline/IndexedDB en dispositivos compartidos.

2. **Persistencia, Concurrencia e Idempotencia (`SQLite WAL` + `JSON`)**
   - Evalúa `server/db.ts`: coherencia entre estado en memoria `db`, transacciones SQLite incrementales (`runDbTransaction`), índices, `ot_repuestos`, `idempotency_keys` (`client_tx_id`) y respaldo JSON asíncrono/diferido (`flushJsonBackupSync`).
   - Busca riesgos de desincronización memoria ↔ SQLite, crecimiento ilimitado de tablas (`historial`, `idempotency_keys`), bloqueos bajo concurrencia multi-dispositivo o reinicios en caliente.

3. **Lógica Operativa del Negocio de Rental (Patio, Arriendo, Taller, Emergencias)**
   - **Control de Arriendos (En Patio vs. En Obra):** Verifica creación/cierre de arriendos en `arriendos`, fechas estimadas de retorno, detección de atrasos, historial por cliente/RUT, bloqueos de doble despacho y qué escenarios comerciales faltan (ej. renovaciones/extensiones de contrato, tarifas diarias automáticas, guías multi-equipo, recepción parcial o devolución con daño imputable al cliente).
   - **Doble Firma en Emergencias y Anti-Spam:** Verifica separación entre 1ra firma en terreno (`ModuloEmergencia.tsx`) y 2da firma exclusiva en `JefaturaEmergenciasTab.tsx`, validación de RUT Módulo 11 y límites por ventana temporal.
   - **Taller, OTs y Bodega:** Consistencia entre apertura/cierre de OT, reversión de repuestos con restauración de stock, costos externos vs mano de obra, y vinculación Presupuesto aprobado ↔ OT.
   - **Informes PDF (`InformePdfModal.tsx`):** Comportamiento de impresión A4 en móvil/desktop, fallos de carga de fotos y trazabilidad de firmas.

4. **Operación en Terreno sin Señal (PWA / Offline) y Calidad de Código**
   - Revisa `offlineStore.ts`, `apiClient.ts`, `vite.config.ts` (Workbox) y los flujos de `RecepcionDespachoTab` y `ModuloEmergencia`: qué ocurre ante conflictos de estado al reconectar (ej. máquina ya recepcionada o despachada por otro operador mientras estuvo offline), límites de cuota IndexedDB con fotos y manejo de errores `4xx`/`5xx` al vaciar la cola `outbox`.
   - Revisa calidad TypeScript, accesibilidad, rendimiento de renderizado con flotas de 3.000+ equipos (paginación/virtualización) y pruebas automatizadas faltantes.

## 3. Formato de Entrega Requerido
Organiza el resultado exactamente en estas 4 secciones:
1. **Hallazgos Críticos (Seguridad, Integridad de Datos o Bloqueos Operativos)** — con archivo, línea aproximada, por qué es riesgoso y solución exacta recomendada.
2. **Brechas en Lógica de Negocio (Rental / Taller / Arriendos / Clientes)** — escenarios reales de patio, obra o facturación que aún quedan sin cubrir o con casos borde.
3. **Resiliencia Offline, PWA y Escalabilidad (3.000+ Equipos / Múltiples Dispositivos)** — conflictos de sincronización, UX móvil en faena y rendimiento.
4. **Hoja de Ruta Priorizada (Top 5 acciones)** — ordenadas de mayor impacto/menor esfuerzo a mayor complejidad, listas para implementar.
